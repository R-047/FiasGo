package com.CIA.a1941037_malabcia3;

public class Venue_data {
    public static String ml_data;
    String ai_data;
    String cl_data;
    String bg_data;

    public static void init_Venue_data(){
        ml_data = "{\n" +
                "\t\"less_details\":{\n" +
                "\t\t\"topic\":\"machine learning\",\n" +
                "\t\t\"venue\":\"ABC auditorium\",\n" +
                "\t\t\"date\":\"2021-01-01\",\n" +
                "\t\t\"time\":\"8:00 am\",\n" +
                "\t\t\"schedule\":[\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"time\":\"9:00 am\",\n" +
                "\t\t\t\t\"activity\":\"registration\"\n" +
                "\t\t\t},\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"time\":\"9:30 am\",\n" +
                "\t\t\t\t\"activity\":\"keynote\"\n" +
                "\t\t\t},\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"time\":\"10:00 am\",\n" +
                "\t\t\t\t\"activity\":\"introduction\"\n" +
                "\t\t\t},\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"time\":\"11:00 am\",\n" +
                "\t\t\t\t\"activity\":\"Hands On Lab\"\n" +
                "\t\t\t},\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"time\":\"12:30 pm\",\n" +
                "\t\t\t\t\"activity\":\"lunch\"\n" +
                "\t\t\t},\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"time\":\"3:00 am\",\n" +
                "\t\t\t\t\"activity\":\"High Tea Networking\"\n" +
                "\t\t\t}\n" +
                "\t\t]\n" +
                "\t},\n" +
                "\t\"more details\":{\n" +
                "\t\t\"topic\":\"machine_learning\",\n" +
                "\t\t\"venue\":\"ABC auditorium\",\n" +
                "\t\t\"date\":\"2021-01-01\",\n" +
                "\t\t\"time\":\"8:00 am\",\n" +
                "\t\t\"brief\": \"Machine learning is the study of computer algorithms that can improve automatically through experience and by the use of data. It is seen as a part of artificial intelligence.\",\n" +
                "\t\t\"speaker\": \"Kai-Fu Lee\"\n" +
                "\t}\n" +
                "}";
    }
}
