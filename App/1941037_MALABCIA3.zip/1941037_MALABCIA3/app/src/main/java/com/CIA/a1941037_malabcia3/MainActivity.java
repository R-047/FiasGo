package com.CIA.a1941037_malabcia3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private CardView ml_cardview, ai_cardview, cloud_cardview, bd_cardview;
    private AlertDialog.Builder DialogBuilder;
    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Venue_data.init_Venue_data();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ml_cardview = findViewById(R.id.ml_card_view);
        ai_cardview = findViewById(R.id.ai_card_view);
        cloud_cardview = findViewById(R.id.cloud_card_view);
        bd_cardview = findViewById(R.id.bd_card_view);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_items, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(this, MoreDetailsActivity.class);

        switch (item.getItemId()) {
            case R.id.ml:
                intent.putExtra("Data", Venue_data.ml_data);
                startActivity(intent);
                return true;
            case R.id.ai:
                intent.putExtra("Data", Venue_data.ml_data);
                startActivity(intent);
                return true;
            case R.id.cl:
                intent.putExtra("Data", Venue_data.ml_data);
                startActivity(intent);
                return true;
            case R.id.bd:
                intent.putExtra("Data", Venue_data.ml_data);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void inflate_dailog(JSONObject Data) throws JSONException {
        DialogBuilder = new AlertDialog.Builder(this);
        final View details_popup = getLayoutInflater().inflate(R.layout.details_popup, null);
        TextView topic = details_popup.findViewById(R.id.topic_tv);
        topic.setText(Data.getJSONObject("less_details").getString("topic"));
        RecyclerView rv = details_popup.findViewById(R.id.schedule_item_cont_rv);
        JSONArray arr = Data.getJSONObject("less_details").getJSONArray("schedule");
        MyAdapter my_adapter = new MyAdapter(this,arr);
        rv.setAdapter(my_adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));
        DialogBuilder.setView(details_popup);
        dialog = DialogBuilder.create();
        dialog.show();
    }

    public void onMlClick(View v) throws JSONException {
        JSONObject json_ml_data = new JSONObject(Venue_data.ml_data);
        inflate_dailog(json_ml_data);
    }
//    public void onAiClick(View v){
//        inflate_dailog("hello");
//    }
//    public void onClClick(View v){
//        inflate_dailog("hello");
//    }
//    public void onBdClick(View v){
//        inflate_dailog("hello");
//    }
}