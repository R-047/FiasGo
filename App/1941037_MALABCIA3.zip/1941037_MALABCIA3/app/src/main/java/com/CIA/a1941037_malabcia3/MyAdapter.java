package com.CIA.a1941037_malabcia3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.myAdapterViewHolder> {


    Context context;
    JSONArray schedule_Arr;

    public MyAdapter(Context context, JSONArray schedule_Arr) {
        this.context = context;
        this.schedule_Arr = schedule_Arr;
    }

    @NonNull
    @Override
    public myAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.schedule_item, parent, false);
        return new myAdapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.myAdapterViewHolder holder, int position) {
        JSONObject schedule_item = null;
        try {
            schedule_item = schedule_Arr.getJSONObject(position);
            String time = schedule_item.getString("time");
            String activity = schedule_item.getString("activity");
            holder.time.setText(time);
            holder.activity.setText(activity);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return schedule_Arr.length();
    }

    public class myAdapterViewHolder extends RecyclerView.ViewHolder {
        TextView time, activity;
        public myAdapterViewHolder(@NonNull View itemView) {
            super(itemView);
            time = itemView.findViewById(R.id.time_tv);
            activity = itemView.findViewById(R.id.activity_tv);
        }
    }
}
