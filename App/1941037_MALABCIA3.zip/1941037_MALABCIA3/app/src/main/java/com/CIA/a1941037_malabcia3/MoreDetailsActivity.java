package com.CIA.a1941037_malabcia3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import org.json.JSONException;
import org.json.JSONObject;

public class MoreDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_details);
        Intent intent = getIntent();
        String data = intent.getStringExtra("Data");
        try {
            JSONObject obj = new JSONObject(data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}